/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grade;

import javax.swing.JOptionPane;

public class Grade {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        int subjectsNumber = Integer.parseInt(JOptionPane.showInputDialog("Enter Number of Subject grades ... "));

        double grades[] = new double[subjectsNumber];

        double sumOfGrades = 0;

        int totalHours = 0;
        double average;

        String resultMsg = " ";

        while (subjectsNumber > 0) {

            // استقبال درجة الماده من المستخدم
            double grade = Double.parseDouble(JOptionPane.showInputDialog("Enter Subject " + subjectsNumber + " grade ... "));
            // استقبال عدد ساعات الماده من المستخدم
            int hour = Integer.parseInt(JOptionPane.showInputDialog("Enter Number of hours for subject " + subjectsNumber));
            // حفظ الدرجات بعد حسابها عن طريق حاصل ضرب قيمة الدرجة في عدد ساعاتها في مصفوفه
            grades[subjectsNumber - 1] = grade * hour;
            // تجميع عدد الساعات
            totalHours += hour;
            // تنقيص بقيمه  واحد لاستقبال الماده القادمة
            subjectsNumber--;
        }

        for (int i = 0; i < grades.length; i++) {
            // جمع الدرجات
            sumOfGrades += grades[i];
        }

        // حساب متوسط 
     
        average = sumOfGrades / totalHours;

        if (average >= 4.5) {
            resultMsg = "A+";
            // تعني ممتاز مرتفع
        } else if (average >= 4 && average < 4.5) {
            resultMsg = "A";
            // تعني ممتاز
        } else if (average >= 3.5 && average < 4) {
            resultMsg = "B+";
            // تعني جيد جدا
        } else if (average >= 3 && average < 3.5) {
            resultMsg = "B";
            // تعني جيد مرتفع
        } else if (average >= 2.5 && average < 3) {
            resultMsg = "C";
            // تعني جيد
        } else if (average >= 2 && average < 2.5) {
            resultMsg = "D";
            // تعني مقبول
        } else if (average <= 1.5) {
            resultMsg = "F";
            // تعني راسب
        }

        JOptionPane.showMessageDialog(null, ("The GPA ") + average + " -->  " + resultMsg);

    }

}
